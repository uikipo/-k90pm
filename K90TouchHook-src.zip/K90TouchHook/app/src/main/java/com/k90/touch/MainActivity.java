package com.k90.touch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * 框架层触控参数调节：
 *   全局模式：所有 App 共用一套参数
 *   单独模式：每个 App 可覆盖，未单独设置的自动回退全局
 */
public class MainActivity extends Activity {

    private static final String G = "persist.sys.k90.";
    private static final String P = "persist.sys.k90.p.";
    private static final String MODE = "persist.sys.k90.mode";

    private static final String[] KEYS = {"touch_slop_dp", "min_fling_dp", "max_fling_dp", "scroll_friction"};
    private static final String[] NAMES = {"触摸防抖 (dp)", "最小滑动速度 (dp/s)", "最大滑动速度 (dp/s)", "滑动摩擦系数"};
    private static final int[] MIN = {4, 10, 2000, 2};
    private static final int[] MAX = {24, 120, 16000, 30};
    private static final int[] STEP = {1, 5, 500, 1};
    private static final int[] DEF = {8, 50, 8000, 15};
    private static final boolean[] FRACTION = {false, false, false, true};

    private final SeekBar[] bars = new SeekBar[4];
    private final TextView[] vals = new TextView[4];

    private RadioButton rbGlobal;
    private RadioButton rbPerApp;
    private TextView status;
    private EditText search;
    private LinearLayout appList;
    private TextView appCount;

    private final List<String[]> apps = new ArrayList<String[]>(); // {label, pkg}
    private Method sGet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            sGet = sp.getDeclaredMethod("get", String.class);
            sGet.setAccessible(true);
        } catch (Throwable ignored) {
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));

        TextView title = new TextView(this);
        title.setText("K90 触控调校");
        title.setTextSize(22);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("写入系统属性，钩子 0.5 秒内读取。需 LSPosed 启用本模块，"
                + "作用域勾「系统框架」+ 需要的 App；已开着的 App 重启后生效。");
        sub.setTextSize(11);
        sub.setPadding(0, dp(4), 0, dp(12));
        root.addView(sub);

        // ---- 模式 ----
        RadioGroup modeGroup = new RadioGroup(this);
        modeGroup.setOrientation(RadioGroup.HORIZONTAL);
        rbGlobal = new RadioButton(this);
        rbGlobal.setText("全局模式");
        rbPerApp = new RadioButton(this);
        rbPerApp.setText("单独模式");
        modeGroup.addView(rbGlobal);
        modeGroup.addView(rbPerApp);
        modeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (busy) return;
                runSu("setprop " + MODE + " " + (checkedId == rbPerApp.getId() ? "1" : "0"));
                status.setText(checkedId == rbPerApp.getId()
                        ? "已切换到单独模式：优先用各 App 的设置"
                        : "已切换到全局模式：所有 App 用同一套参数");
            }
        });
        root.addView(modeGroup);

        // ---- 全局滑块 ----
        sectionTitle(root, "全局设置");
        for (int i = 0; i < KEYS.length; i++) {
            addRow(root, i);
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(12), 0, 0);

        Button apply = new Button(this);
        apply.setText("应用全局");
        apply.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                applyGlobal();
            }
        });
        row.addView(apply, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button reset = new Button(this);
        reset.setText("恢复默认");
        reset.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                resetGlobal();
            }
        });
        row.addView(reset, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);

        // ---- 单独 App ----
        sectionTitle(root, "单独 App 设置");
        TextView tip = new TextView(this);
        tip.setText("点 App 名称单独调参；未单独设置的 App 自动跟随全局。");
        tip.setTextSize(11);
        root.addView(tip);

        search = new EditText(this);
        search.setHint("搜索 App");
        search.setSingleLine(true);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                renderApps(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        root.addView(search);

        appCount = new TextView(this);
        appCount.setTextSize(11);
        root.addView(appCount);

        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        root.addView(appList);

        status = new TextView(this);
        status.setTextSize(11);
        status.setPadding(0, dp(14), 0, 0);
        root.addView(status);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        loadApps();
        loadState();
    }

    private void sectionTitle(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(17);
        t.setPadding(0, dp(22), 0, dp(6));
        root.addView(t);
    }

    private void addRow(LinearLayout root, final int i) {
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setPadding(0, dp(8), 0, 0);

        TextView name = new TextView(this);
        name.setText(NAMES[i]);
        name.setTextSize(14);
        head.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView v = new TextView(this);
        v.setTextSize(14);
        head.addView(v);
        vals[i] = v;

        root.addView(head);

        SeekBar bar = new SeekBar(this);
        bar.setMax((MAX[i] - MIN[i]) / STEP[i]);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                vals[i].setText(display(i, sliderToValue(i, progress)));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        root.addView(bar);
        bars[i] = bar;
    }

    private int sliderToValue(int i, int progress) {
        return MIN[i] + progress * STEP[i];
    }

    private String display(int i, int value) {
        if (FRACTION[i]) {
            return String.format(Locale.US, "%.3f", value / 1000.0f);
        }
        return String.valueOf(value);
    }

    private String propValue(int i, int value) {
        return FRACTION[i] ? String.format(Locale.US, "%.3f", value / 1000.0f) : String.valueOf(value);
    }

    private int parseValue(int i, String raw) {
        if (raw == null || raw.length() == 0) {
            return Integer.MIN_VALUE;
        }
        try {
            float f = Float.parseFloat(raw.trim());
            return FRACTION[i] ? Math.round(f * 1000f) : Math.round(f);
        } catch (Throwable t) {
            return Integer.MIN_VALUE;
        }
    }

    // ---------------- 全局 ----------------
    private void applyGlobal() {
        StringBuilder cmd = new StringBuilder();
        StringBuilder log = new StringBuilder();
        for (int i = 0; i < KEYS.length; i++) {
            String v = propValue(i, sliderToValue(i, bars[i].getProgress()));
            cmd.append("setprop ").append(G).append(KEYS[i]).append(' ').append(v).append("; ");
            log.append(KEYS[i]).append('=').append(v).append(' ');
        }
        boolean ok = runSu(cmd.toString());
        status.setText(ok ? "全局已应用：" + log : "失败（需要 root 权限）");
        loadGlobalValues();
    }

    private void resetGlobal() {
        StringBuilder cmd = new StringBuilder();
        for (String k : KEYS) {
            cmd.append("setprop ").append(G).append(k).append(" \"\"; ");
        }
        boolean ok = runSu(cmd.toString());
        status.setText(ok ? "全局已恢复默认" : "失败（需要 root 权限）");
        loadGlobalValues();
    }

    private void loadGlobalValues() {
        for (int i = 0; i < KEYS.length; i++) {
            int v = parseValue(i, prop(G + KEYS[i]));
            if (v == Integer.MIN_VALUE) {
                v = DEF[i];
            }
            int clamped = Math.max(MIN[i], Math.min(MAX[i], v));
            bars[i].setProgress((clamped - MIN[i]) / STEP[i]);
            vals[i].setText(display(i, sliderToValue(i, bars[i].getProgress())));
        }
    }

    private void loadState() {
        boolean perApp = "1".equals(prop(MODE));
        busy = true;
        if (perApp) {
            rbPerApp.setChecked(true);
        } else {
            rbGlobal.setChecked(true);
        }
        busy = false;
        loadGlobalValues();
        renderApps(search.getText().toString());
    }

    // ---------------- 单独 App ----------------
    private void loadApps() {
        try {
            PackageManager pm = getPackageManager();
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(intent, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                String label = String.valueOf(ri.loadLabel(pm));
                apps.add(new String[]{label, pkg});
            }
            Collections.sort(apps, new Comparator<String[]>() {
                @Override
                public int compare(String[] a, String[] b) {
                    return a[0].compareToIgnoreCase(b[0]);
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void renderApps(String filter) {
        if (appList == null) {
            return;
        }
        appList.removeAllViews();
        String f = filter == null ? "" : filter.trim().toLowerCase(Locale.US);
        int shown = 0;
        for (String[] a : apps) {
            if (f.length() > 0
                    && !a[0].toLowerCase(Locale.US).contains(f)
                    && !a[1].toLowerCase(Locale.US).contains(f)) {
                continue;
            }
            if (shown >= 120) {
                break;
            }
            shown++;
            final String pkg = a[1];
            final String label = a[0];

            Button b = new Button(this);
            String mark = perAppMark(pkg);
            b.setText(label + (mark.length() > 0 ? "   " + mark : ""));
            b.setAllCaps(false);
            b.setTextSize(13);
            b.setGravity(android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.LEFT);
            b.setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {
                    showAppDialog(label, pkg);
                }
            });
            appList.addView(b);
        }
        if (appCount != null) {
            appCount.setText("共 " + apps.size() + " 个 App，显示 " + shown + " 个");
        }
    }

    private String perAppMark(String pkg) {
        int set = 0;
        for (String k : KEYS) {
            String v = prop(P + pkg + "." + k);
            if (v != null && v.length() > 0) {
                set++;
            }
        }
        if (set == 0) {
            return "";
        }
        return "（单独设置 " + set + " 项）";
    }

    private void showAppDialog(String label, final String pkg) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(10));

        final CheckBox use = new CheckBox(this);
        use.setText("使用单独设置（不勾 = 跟随全局）");
        boolean hasAny = perAppMark(pkg).length() > 0;
        use.setChecked(hasAny);
        box.addView(use);

        final SeekBar[] db = new SeekBar[4];
        final TextView[] dv = new TextView[4];
        for (int i = 0; i < KEYS.length; i++) {
            LinearLayout head = new LinearLayout(this);
            head.setOrientation(LinearLayout.HORIZONTAL);
            TextView n = new TextView(this);
            n.setText(NAMES[i]);
            n.setTextSize(13);
            head.addView(n, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            final TextView value = new TextView(this);
            value.setTextSize(13);
            head.addView(value);
            dv[i] = value;
            box.addView(head);

            final int idx = i;
            SeekBar sb = new SeekBar(this);
            sb.setMax((MAX[i] - MIN[i]) / STEP[i]);
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    dv[idx].setText(display(idx, sliderToValue(idx, progress)));
                }

                @Override
                public void onStartTrackingTouch(SeekBar s) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar s) {
                }
            });
            box.addView(sb);
            db[i] = sb;

            int current = parseValue(i, prop(P + pkg + "." + KEYS[i]));
            if (current == Integer.MIN_VALUE) {
                current = parseValue(i, prop(G + KEYS[i]));
            }
            if (current == Integer.MIN_VALUE) {
                current = DEF[i];
            }
            int clamped = Math.max(MIN[i], Math.min(MAX[i], current));
            sb.setProgress((clamped - MIN[i]) / STEP[i]);
            value.setText(display(i, sliderToValue(i, sb.getProgress())));
        }

        new AlertDialog.Builder(this)
                .setTitle(label + "\n" + pkg)
                .setView(box)
                .setPositiveButton("保存", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        StringBuilder cmd = new StringBuilder();
                        if (use.isChecked()) {
                            for (int i = 0; i < KEYS.length; i++) {
                                cmd.append("setprop ").append(P).append(pkg).append('.')
                                        .append(KEYS[i]).append(' ')
                                        .append(propValue(i, sliderToValue(i, db[i].getProgress())))
                                        .append("; ");
                            }
                        } else {
                            for (int i = 0; i < KEYS.length; i++) {
                                cmd.append("setprop ").append(P).append(pkg).append('.')
                                        .append(KEYS[i]).append(" \"\"; ");
                            }
                        }
                        boolean ok = runSu(cmd.toString());
                        status.setText(ok
                                ? (pkg + (use.isChecked() ? " 已保存单独设置" : " 已改为跟随全局"))
                                : "保存失败（需要 root 权限）");
                        renderApps(search.getText().toString());
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ---------------- 工具 ----------------
    private boolean busy = false;

    private static boolean runSu(String cmd) {
        try {
            Process p = new ProcessBuilder("/system/bin/sh", "-c",
                    "su -c '" + cmd.replace("'", "'\\''") + "'")
                    .redirectErrorStream(true)
                    .start();
            return p.waitFor() == 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private String prop(String key) {
        try {
            if (sGet != null) {
                return (String) sGet.invoke(null, key);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
