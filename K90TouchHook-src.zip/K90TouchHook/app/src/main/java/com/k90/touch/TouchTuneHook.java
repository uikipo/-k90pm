package com.k90.touch;

import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.ViewConfiguration;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 框架层触控参数钩子（LSPosed）
 *
 * 覆盖 ViewConfiguration 的 4 个值：
 *   touch slop         -> 触摸防抖（系统识别拖动前允许的触点偏移）
 *   min fling velocity -> 最小滑动速度（达到才触发惯性滑动）
 *   max fling velocity -> 最大滑动速度（甩动上限）
 *   scroll friction    -> 滑动摩擦系数（越小滑得越远）
 *
 * 参数来自系统属性（任何 App 都能读到，KSU 模块 WebUI 用 setprop 写入）：
 *   persist.sys.k90_touch_slop_dp     0 或空 = 不覆盖
 *   persist.sys.k90_min_fling_dp      0 = 不覆盖
 *   persist.sys.k90_max_fling_dp      0 = 不覆盖
 *   persist.sys.k90_scroll_friction   <=0 = 不覆盖
 *
 * 每次调用带 500ms 缓存重新读属性，所以 WebUI 改完即时生效；
 * 已经初始化过的 View / Scroller 需要重启 App 才会用上新值。
 */
public class TouchTuneHook implements IXposedHookLoadPackage {

    private static final String P_SLOP      = "persist.sys.k90_touch_slop_dp";
    private static final String P_MIN_FLING = "persist.sys.k90_min_fling_dp";
    private static final String P_MAX_FLING = "persist.sys.k90_max_fling_dp";
    private static final String P_FRICTION  = "persist.sys.k90_scroll_friction";

    private static final long TTL_MS = 500L;

    private static volatile int sSlopDp = 0;
    private static volatile int sMinFlingDp = 0;
    private static volatile int sMaxFlingDp = 0;
    private static volatile float sFriction = -1f;
    private static volatile long sStamp = 0L;

    private static Method sPropGet;
    private static boolean sInstalled = false;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            install();
        } catch (Throwable t) {
            XposedBridge.log("K90Touch install failed: " + t);
        }
    }

    private static synchronized void install() {
        if (sInstalled) {
            return;
        }
        sInstalled = true;

        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            sPropGet = sp.getDeclaredMethod("get", String.class);
            sPropGet.setAccessible(true);
        } catch (Throwable ignored) {
        }

        Class<?> vc = ViewConfiguration.class;
        int ok = 0;

        try {
            XposedBridge.hookAllMethods(vc, "get", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object result = param.getResult();
                    if (result != null) {
                        applyToInstance(result);
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook get() failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScaledTouchSlop", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        if (sSlopDp > 0) {
                            param.setResult(dp2px(sSlopDp));
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScaledTouchSlop failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScaledMinimumFlingVelocity", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        if (sMinFlingDp > 0) {
                            param.setResult(dp2px(sMinFlingDp));
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScaledMinimumFlingVelocity failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScaledMaximumFlingVelocity", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        if (sMaxFlingDp > 0) {
                            param.setResult(dp2px(sMaxFlingDp));
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScaledMaximumFlingVelocity failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScrollFriction", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        if (sFriction > 0f) {
                            param.setResult(sFriction);
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScrollFriction failed: " + t);
        }

        XposedBridge.log("K90Touch hooks installed: " + ok + "/5");
    }

    private static void applyToInstance(Object vc) {
        try {
            refresh();
        } catch (Throwable ignored) {
        }
        if (sSlopDp > 0) {
            safeSetInt(vc, "mTouchSlop", dp2px(sSlopDp));
        }
        if (sMinFlingDp > 0) {
            safeSetInt(vc, "mMinimumFlingVelocity", dp2px(sMinFlingDp));
        }
        if (sMaxFlingDp > 0) {
            safeSetInt(vc, "mMaximumFlingVelocity", dp2px(sMaxFlingDp));
        }
    }

    private static void safeSetInt(Object target, String field, int value) {
        try {
            XposedHelpers.setIntField(target, field, value);
        } catch (Throwable ignored) {
        }
    }

    private static void refresh() {
        long now = System.currentTimeMillis();
        if (now - sStamp < TTL_MS) {
            return;
        }
        sStamp = now;
        sSlopDp = readInt(P_SLOP, sSlopDp);
        sMinFlingDp = readInt(P_MIN_FLING, sMinFlingDp);
        sMaxFlingDp = readInt(P_MAX_FLING, sMaxFlingDp);
        sFriction = readFloat(P_FRICTION, sFriction);
    }

    private static String prop(String key) {
        try {
            if (sPropGet != null) {
                return (String) sPropGet.invoke(null, key);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static int readInt(String key, int def) {
        String v = prop(key);
        if (v == null || v.length() == 0) {
            return def;
        }
        try {
            return Integer.parseInt(v.trim());
        } catch (Throwable t) {
            return def;
        }
    }

    private static float readFloat(String key, float def) {
        String v = prop(key);
        if (v == null || v.length() == 0) {
            return def;
        }
        try {
            return Float.parseFloat(v.trim());
        } catch (Throwable t) {
            return def;
        }
    }

    private static int dp2px(int dp) {
        try {
            DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
            return Math.round(dp * dm.density);
        } catch (Throwable t) {
            return dp;
        }
    }
}
