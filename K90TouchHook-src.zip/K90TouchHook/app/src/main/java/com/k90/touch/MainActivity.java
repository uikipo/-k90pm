package com.k90.touch;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import java.lang.reflect.Method;

/** 只用来查看当前参数 / 确认模块是否装好，不提供修改入口（修改在 KSU WebUI 里）。 */
public class MainActivity extends Activity {

    private static Method sGet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            sGet = sp.getDeclaredMethod("get", String.class);
            sGet.setAccessible(true);
        } catch (Throwable ignored) {
        }

        StringBuilder sb = new StringBuilder();
        sb.append("框架层触控参数（LSPosed）\n\n");
        sb.append("启用方法\n");
        sb.append("1. LSPosed 里启用本模块\n");
        sb.append("2. 作用域勾选「系统框架」+ 想要生效的 App\n");
        sb.append("3. 参数用模块 WebUI 的滑块改（写 persist.sys.*）\n");
        sb.append("4. 已开着的 App 重启一次才会用上新值\n\n");
        sb.append("当前参数\n");
        sb.append("触摸防抖 touch_slop_dp    = ").append(p("persist.sys.k90_touch_slop_dp")).append('\n');
        sb.append("最小滑动 min_fling_dp     = ").append(p("persist.sys.k90_min_fling_dp")).append('\n');
        sb.append("最大滑动 max_fling_dp     = ").append(p("persist.sys.k90_max_fling_dp")).append('\n');
        sb.append("摩擦系数 scroll_friction  = ").append(p("persist.sys.k90_scroll_friction")).append('\n');
        sb.append("\n空 / 0 表示不覆盖，走系统默认。");

        TextView tv = new TextView(this);
        tv.setText(sb.toString());
        tv.setTextSize(14);
        tv.setPadding(56, 72, 56, 56);

        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        setContentView(sv);
    }

    private static String p(String key) {
        try {
            if (sGet != null) {
                String v = (String) sGet.invoke(null, key);
                return (v == null || v.length() == 0) ? "(未设置)" : v;
            }
        } catch (Throwable ignored) {
        }
        return "(未设置)";
    }
}
