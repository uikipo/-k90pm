#!/data/data/com.termux/files/usr/bin/bash
# 在 Termux 里一键编译（需要先装 openjdk-17 与 Android SDK）
set -e
cd "$(dirname "$0")"
echo "== 环境检查 =="
java -version 2>&1 | head -2
: "${ANDROID_HOME:=$HOME/android-sdk}"
echo "ANDROID_HOME=$ANDROID_HOME"
gradle assembleRelease --no-daemon
ls -l app/build/outputs/apk/release/
echo "完成，APK 在 app/build/outputs/apk/release/"
