package com.k90.touch;

import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.ViewConfiguration;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 框架层触控参数钩子（LSPosed）—— 支持全局 / 单 App 两种模式
 *
 * 参数来源（系统属性，任何 App 都能读，App 界面和 KSU WebUI 都写这一套）：
 *
 *   模式开关：persist.sys.k90.mode   0 = 全局模式（默认）  1 = 单独模式
 *
 *   全局值：
 *     persist.sys.k90.touch_slop_dp        触摸防抖，dp（0/空 = 不覆盖）
 *     persist.sys.k90.min_fling_dp         最小滑动速度，dp/s
 *     persist.sys.k90.max_fling_dp         最大滑动速度，dp/s
 *     persist.sys.k90.scroll_friction      滑动摩擦系数，如 0.015
 *
 *   单个 App 覆盖值（仅「单独模式」生效，未设置则回退全局）：
 *     persist.sys.k90.p.<包名>.touch_slop_dp
 *     persist.sys.k90.p.<包名>.min_fling_dp
 *     persist.sys.k90.p.<包名>.max_fling_dp
 *     persist.sys.k90.p.<包名>.scroll_friction
 *
 * 每次调用带 500ms 缓存重读属性，改完即时生效；
 * 已初始化的 View / Scroller 需要重启 App 才用上新值。
 */
public class TouchTuneHook implements IXposedHookLoadPackage {

    private static final String MODE_KEY = "persist.sys.k90.mode";
    private static final String GLOBAL_PREFIX = "persist.sys.k90.";
    private static final String PER_APP_PREFIX = "persist.sys.k90.p.";

    private static final long TTL_MS = 500L;

    private static final int UNSET = Integer.MIN_VALUE;
    private static final float UNSET_F = -2f;

    private static volatile int sMode = 0;
    private static volatile String sPkg;

    private static volatile int sSlopDp = 0;
    private static volatile int sMinFlingDp = 0;
    private static volatile int sMaxFlingDp = 0;
    private static volatile float sFriction = -1f;

    private static volatile int sPSlop = UNSET;
    private static volatile int sPMin = UNSET;
    private static volatile int sPMax = UNSET;
    private static volatile float sPFric = UNSET_F;

    private static volatile long sStamp = 0L;

    private static Method sPropGet;
    private static boolean sInstalled = false;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            if (lpparam != null && lpparam.packageName != null) {
                sPkg = lpparam.packageName;
            }
            install();
        } catch (Throwable t) {
            XposedBridge.log("K90Touch install failed: " + t);
        }
    }

    private static synchronized void install() {
        if (sInstalled) {
            return;
        }
        sInstalled = true;

        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            sPropGet = sp.getDeclaredMethod("get", String.class);
            sPropGet.setAccessible(true);
        } catch (Throwable ignored) {
        }

        Class<?> vc = ViewConfiguration.class;
        int ok = 0;

        try {
            XposedBridge.hookAllMethods(vc, "get", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object result = param.getResult();
                    if (result != null) {
                        applyToInstance(result);
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook get() failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScaledTouchSlop", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        int dp = slopDp();
                        if (dp > 0) {
                            param.setResult(dp2px(dp));
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScaledTouchSlop failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScaledMinimumFlingVelocity", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        int dp = minFlingDp();
                        if (dp > 0) {
                            param.setResult(dp2px(dp));
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScaledMinimumFlingVelocity failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScaledMaximumFlingVelocity", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        int dp = maxFlingDp();
                        if (dp > 0) {
                            param.setResult(dp2px(dp));
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScaledMaximumFlingVelocity failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(vc, "getScrollFriction", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        refresh();
                        float f = friction();
                        if (f > 0f) {
                            param.setResult(f);
                        }
                    } catch (Throwable ignored) {
                    }
                }
            });
            ok++;
        } catch (Throwable t) {
            XposedBridge.log("K90Touch hook getScrollFriction failed: " + t);
        }

        XposedBridge.log("K90Touch hooks installed: " + ok + "/5 pkg=" + sPkg);
    }

    private static int slopDp() {
        return (sMode == 1 && sPSlop != UNSET) ? sPSlop : sSlopDp;
    }

    private static int minFlingDp() {
        return (sMode == 1 && sPMin != UNSET) ? sPMin : sMinFlingDp;
    }

    private static int maxFlingDp() {
        return (sMode == 1 && sPMax != UNSET) ? sPMax : sMaxFlingDp;
    }

    private static float friction() {
        return (sMode == 1 && sPFric > UNSET_F) ? sPFric : sFriction;
    }

    private static void applyToInstance(Object vc) {
        try {
            refresh();
        } catch (Throwable ignored) {
        }
        int slop = slopDp();
        if (slop > 0) {
            safeSetInt(vc, "mTouchSlop", dp2px(slop));
        }
        int minF = minFlingDp();
        if (minF > 0) {
            safeSetInt(vc, "mMinimumFlingVelocity", dp2px(minF));
        }
        int maxF = maxFlingDp();
        if (maxF > 0) {
            safeSetInt(vc, "mMaximumFlingVelocity", dp2px(maxF));
        }
    }

    private static void safeSetInt(Object target, String field, int value) {
        try {
            XposedHelpers.setIntField(target, field, value);
        } catch (Throwable ignored) {
        }
    }

    private static void refresh() {
        long now = System.currentTimeMillis();
        if (now - sStamp < TTL_MS) {
            return;
        }
        sStamp = now;

        sMode = readInt(MODE_KEY, 0);
        sSlopDp = readInt(GLOBAL_PREFIX + "touch_slop_dp", sSlopDp);
        sMinFlingDp = readInt(GLOBAL_PREFIX + "min_fling_dp", sMinFlingDp);
        sMaxFlingDp = readInt(GLOBAL_PREFIX + "max_fling_dp", sMaxFlingDp);
        sFriction = readFloat(GLOBAL_PREFIX + "scroll_friction", sFriction);

        String pkg = sPkg;
        if (sMode == 1 && pkg != null) {
            String base = PER_APP_PREFIX + pkg + ".";
            sPSlop = readInt(base + "touch_slop_dp", UNSET);
            sPMin = readInt(base + "min_fling_dp", UNSET);
            sPMax = readInt(base + "max_fling_dp", UNSET);
            sPFric = readFloat(base + "scroll_friction", UNSET_F);
        } else {
            sPSlop = UNSET;
            sPMin = UNSET;
            sPMax = UNSET;
            sPFric = UNSET_F;
        }
    }

    private static String prop(String key) {
        try {
            if (sPropGet != null) {
                return (String) sPropGet.invoke(null, key);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static int readInt(String key, int def) {
        String v = prop(key);
        if (v == null || v.length() == 0) {
            return def;
        }
        try {
            return Integer.parseInt(v.trim());
        } catch (Throwable t) {
            return def;
        }
    }

    private static float readFloat(String key, float def) {
        String v = prop(key);
        if (v == null || v.length() == 0) {
            return def;
        }
        try {
            return Float.parseFloat(v.trim());
        } catch (Throwable t) {
            return def;
        }
    }

    private static int dp2px(int dp) {
        try {
            DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
            return Math.round(dp * dm.density);
        } catch (Throwable t) {
            return dp;
        }
    }
}
