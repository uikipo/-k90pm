# K90 触控调校（LSPosed 模块）

给 Redmi K90 Pro Max 的**框架层**触控参数做实时覆盖，配合 KernelSU 模块
`Redmi_k90pm_config` 的 WebUI 使用。

覆盖的 4 个值（`android.view.ViewConfiguration`）：

| 属性 | 含义 | 默认值（本机实测） |
|---|---|---|
| `persist.sys.k90_touch_slop_dp` | 触摸防抖（拖动前允许的触点偏移） | 8 dp |
| `persist.sys.k90_scroll_friction` | 滑动摩擦系数 | 0.015 |
| `persist.sys.k90_min_fling_dp` | 最小滑动速度 | 50 dp/s |
| `persist.sys.k90_max_fling_dp` | 最大滑动速度 | 8000 dp/s |

值 `0` 或空 = 不覆盖，走系统默认。

## 为什么用系统属性存参数

Android 里并不是每个 App 都能读 `/data/adb`、`/data/local/tmp` 或 `/odm`（实测
untrusted_app 全部不可读），而 `persist.sys.*` 属性任何 App 都能读。
所以参数放在属性里，KSU 模块 WebUI 用 `setprop` 写入，钩子每次调用带 500ms
缓存重新读——改完即时生效，不用重启系统。

## 编译（手机上没有 JDK/aapt/d8，必须借助外部环境）

### 方式 A：GitHub Actions（不需要电脑，推荐）

1. 新建一个空仓库，把本目录全部文件上传（手机浏览器也能传）
2. 仓库进 Actions → `Build APK` → Run workflow
3. 跑完在 Actions 里下载 `K90TouchHook-apk` 产物
4. 安装 APK

### 方式 B：Android Studio

直接用 Android Studio 打开本目录，Build → Build APK(s)。
需要 JDK 17 + Android SDK 34。

### 方式 C：Termux

```bash
pkg install openjdk-17 gradle
# 再装 Android SDK（cmdline-tools + platforms;android-34 + build-tools;34.0.0）
gradle assembleRelease
```

## 启用

1. LSPosed → 模块 → 启用 **K90 触控调校**
2. 作用域：
   - 勾「系统框架」（system_server：对话框、状态栏等）
   - **再勾你希望生效的 App**（每个 App 的 ViewConfiguration 在自己的进程里，
     不勾就不会生效）：桌面、微信、浏览器、游戏等
3. 重启手机或软重启
4. 在 KSU 模块 WebUI 的「框架层」卡片里拖滑块

## 生效说明

- `getScrollFriction()` / `getScaledTouchSlop()` 等被调用时读属性 → 新值对
  **新创建的控件/Scroller** 生效；已经创建的 View（比如正开着的列表）要重启
  App 才会用新值。
- 只影响 `ViewConfiguration`，不动触控 IC、不影响指纹/防误触。
